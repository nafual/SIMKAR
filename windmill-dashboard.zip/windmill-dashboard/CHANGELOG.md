## [1.0.2](https://github.com/estevanmaito/windmill-dashboard/compare/1.0.1...1.0.2) (2020-07-18)

This is the first real "release". Nothing has changed, except for some SEO meta tags, that are no longer needed as the project is no longer hosted isolated.

This way you don't have to delete almost half of the `index.html` head just to start a project.

## 1.0.1 (2020-07-01)
